#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDir>
#include <QStringList>
#include <QPixmap>
#include <QMessageBox>
#include <QBasicTimer>
#include <QFileDialog>
#include <ctime>



MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),

    ui(new Ui::MainWindow)
{

    tries=0;
    gamesPlayed=0;
   solvedSquares=0;
 QDir directory;
           if(customImages==false){
    directory=QDir ("images/");
           }
    QStringList filters;
    filters<<"*.png"<<"*.jpeg"<<"*.bmp"<<"*.gif"<<"*.jpg"<<"*.pbm"<<"*.pgm"<<"*.ppm"<<"*.tiff"<<"*.xbm"<<"*.xpm";
    directory.setNameFilters(filters);
    QStringList files = directory.entryList();
int numOfFiles =files.length()-1;
 bool hasUsed=false;
 srand(static_cast<unsigned int>(time(0)));//I found this to be able to use the current time to make sure that the randomization is different each time

for(int i=0;i<10;++i){//time to get our 10 random images
   hasUsed=false;

    int rando = rand()%numOfFiles;
    QString imagePath;
    if(customImages==false){
       imagePath=("images/");
    }
         imagePath.append(files.takeAt(rando));
         if(i>0){
    for(int g=0;g<i;g++){//check if the image was used before
        if(imagePath==theFiles[g])
            hasUsed=true;
    }
         }
    if(hasUsed==false)
  theFiles[i]=imagePath;

    else if(hasUsed==true){
        i--;//if it would have been a duplicate, rechoose it.
    }
//  theFiles[i]=theFiles[i].scaled(81,81);
    files.removeAt(rando);
    numOfFiles=numOfFiles-2;
}
for(int i=0;i<20;i++){
    boardImg[i]=0;//make sure everything is set for the for loops.
}
for(int a=0;a<2;a++){
     for(int b=0;b<10;b++){
        int rando =rand()%19;
        if(boardImg[rando]==0)
            boardImg[rando]=b;
        else
            b=b--;//try that number again
}
}

turns[0]=NULL;
turns[1]=NULL;
//int index=boardImg[1];
//QPixmap thePic(this->theFiles[index]);
//ui->label_2->setPixmap(thePic);
//ui->label->hide();
//thePic(theFiles[boardImg[0]]);
//ui->label->setPixmap( thePic);
//ui->actionPlay_again->setDisabled(true);
  //  QBasicTimer * theTimer=new QBasicTimer;
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}




void MainWindow::on_pushButton_2_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[1];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_2->setPixmap(thePic);
    ui->pushButton_2->hide();//hide button, show picture
    ui->label_2->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_2;
        turn[0]=ui->pushButton_2;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_2;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_2;
        turns[1]=ui->label_2;
         theTimer->start(250);
    }

}



void MainWindow::on_pushButton_1_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[0];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_1->setPixmap(thePic);
    ui->pushButton_1->hide();//hide button, show picture
    ui->label_1->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_1;
        turn[0]=ui->pushButton_1;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_1;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_1;
        turns[1]=ui->label_1;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_4_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[3];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_4->setPixmap(thePic);
    ui->pushButton_4->hide();//hide button, show picture
    ui->label_4->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_4;
        turn[0]=ui->pushButton_4;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_4;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_4;
        turns[1]=ui->label_4;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_3_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[2];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_3->setPixmap(thePic);
    ui->pushButton_3->hide();//hide button, show picture
    ui->label_3->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_3;
        turn[0]=ui->pushButton_3;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_3;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_3;
        turns[1]=ui->label_3;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_8_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[7];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_8->setPixmap(thePic);
    ui->pushButton_8->hide();//hide button, show picture
    ui->label_8->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_8;
        turn[0]=ui->pushButton_8;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_8;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_8;
        turns[1]=ui->label_8;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_6_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[5];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_6->setPixmap(thePic);
    ui->pushButton_6->hide();//hide button, show picture
    ui->label_6->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_6;
        turn[0]=ui->pushButton_6;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_6;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_6;
        turns[1]=ui->label_6;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_7_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[6];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_7->setPixmap(thePic);
    ui->pushButton_7->hide();//hide button, show picture
    ui->label_7->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_7;
        turn[0]=ui->pushButton_7;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_7;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_7;
        turns[1]=ui->label_7;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_5_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[4];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_5->setPixmap(thePic);
    ui->pushButton_5->hide();//hide button, show picture
    ui->label_5->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_5;
        turn[0]=ui->pushButton_5;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_5;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_5;
        turns[1]=ui->label_5;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_12_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[11];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_12->setPixmap(thePic);
    ui->pushButton_12->hide();//hide button, show picture
    ui->label_12->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_12;
        turn[0]=ui->pushButton_12;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_12;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_12;
        turns[1]=ui->label_12;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_11_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[10];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_11->setPixmap(thePic);
    ui->pushButton_11->hide();//hide button, show picture
    ui->label_11->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_11;
        turn[0]=ui->pushButton_11;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_11;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_11;
        turns[1]=ui->label_11;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_10_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[9];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_10->setPixmap(thePic);
    ui->pushButton_10->hide();//hide button, show picture
    ui->label_10->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_10;
        turn[0]=ui->pushButton_10;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_10;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_10;
        turns[1]=ui->label_10;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_9_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[8];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_9->setPixmap(thePic);
    ui->pushButton_9->hide();//hide button, show picture
    ui->label_9->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_9;
        turn[0]=ui->pushButton_9;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_9;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_9;
        turns[1]=ui->label_9;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_16_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[15];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_16->setPixmap(thePic);
    ui->pushButton_16->hide();//hide button, show picture
    ui->label_16->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_16;
        turn[0]=ui->pushButton_16;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_16;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_16;
        turns[1]=ui->label_16;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_15_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[14];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_15->setPixmap(thePic);
    ui->pushButton_15->hide();//hide button, show picture
    ui->label_15->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_15;
        turn[0]=ui->pushButton_15;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_15;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_15;
        turns[1]=ui->label_15;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_14_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[13];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_14->setPixmap(thePic);
    ui->pushButton_14->hide();//hide button, show picture
    ui->label_14->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_14;
        turn[0]=ui->pushButton_14;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_14;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_14;
        turns[1]=ui->label_14;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_13_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[12];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_13->setPixmap(thePic);
    ui->pushButton_13->hide();//hide button, show picture
    ui->label_13->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_13;
        turn[0]=ui->pushButton_13;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_13;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_13;
        turns[1]=ui->label_13;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_20_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[19];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_20->setPixmap(thePic);
    ui->pushButton_20->hide();//hide button, show picture
    ui->label_20->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_20;
        turn[0]=ui->pushButton_20;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_20;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_20;
        turns[1]=ui->label_20;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_18_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[17];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_18->setPixmap(thePic);
    ui->pushButton_18->hide();//hide button, show picture
    ui->label_18->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_18;
        turn[0]=ui->pushButton_18;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_18;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_18;
        turns[1]=ui->label_18;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_17_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[16];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_17->setPixmap(thePic);
    ui->pushButton_17->hide();//hide button, show picture
    ui->label_17->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_17;
        turn[0]=ui->pushButton_17;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_17;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_17;
        turns[1]=ui->label_17;
         theTimer->start(250);
    }
}

void MainWindow::on_pushButton_19_clicked(bool checked)
{
    theTimer=new QTimer(this);//starts the timer
        ui->lcdNumber_3->display(solvedSquares);
        ui->lcdNumber->display(gamesPlayed);
        //updates the info from the last move
    int index=boardImg[18];//this index represents 0-9 which is an image 0-9
    tries=tries++;//stores the number of tries this game.
    ui->lcdNumber_2->display(tries);
    QPixmap thePic;
    thePic.load(theFiles[index]);//load up the image from index
    ui->label_19->setPixmap(thePic);
    ui->pushButton_19->hide();//hide button, show picture
    ui->label_19->show();
    connect(theTimer,SIGNAL(timeout()),this,SLOT(check()));//once timer hits 0, do a check
    if(turns[0]==NULL){//if no other buttons have been checked, its the first.
        turns[0]=ui->label_19;
        turn[0]=ui->pushButton_19;
                turnsIndex[0]=index;
}
    else if(turns[1]==NULL){
        turns[1]=ui->label_19;
        turnsIndex[1]=index;
        turn[1]=ui->pushButton_19;
        turns[1]=ui->label_19;
         theTimer->start(250);
    }
}


void MainWindow::on_actionExit_triggered()
{
    exit(1);
}

void MainWindow::on_actionAbout_triggered()
{
    QMessageBox about;
    about.setText("This game has been brought to you by Jonathan Levy");
    about.setInformativeText("CS 340,April 2012");
    about.exec();
}

void MainWindow::on_actionHow_to_Play_triggered()
{
    QMessageBox howTo;
    howTo.setText("click a single box to reveal an image. Click a second box to see if you have a match.\n"
                  "The game will keep track of how many tries it took to finish.\n"
                  "You can play as many times as you want, just hit play again. your wins will be counted.\n"
                  "If some statistic doesn't update, don't worry. It will on the next tile click.\n"
                  "You can choose your own images, but if there are less than 10 in the directory, it will be rejected and revert to the default. Hitting play again resets all your settings, including custom images.");
            howTo.exec();
}
void MainWindow::on_actionImport_your_own_images_triggered()
{
    //   ui->lcdNumber->display(gamesPlayed);
       QDir directory;
       QString path=QFileDialog::getExistingDirectory(this,tr("directory"),directory.path());

       if(path.isNull()==false){
           //we go browsing for directories

           directory.setPath(path);
           ui->listWidget->clear();
           ui->listWidget->addItems(directory.entryList());
           ui->listWidget->hide();//make sure its hidden when done.
       }
       customImages=true;

       tries=0;
       //gamesPlayed=0;
      solvedSquares=0;
    //QDir directory;
              if(customImages==false){
       directory=QDir ("images/");
              }
       QStringList filters;
       filters<<"*.png"<<"*.jpeg"<<"*.bmp"<<"*.gif"<<"*.jpg"<<"*.pbm"<<"*.pgm"<<"*.ppm"<<"*.tiff"<<"*.xbm"<<"*.xpm";
       directory.setNameFilters(filters);
       QStringList files = directory.entryList();
       if(files.length()>=10){
    delete ui->label_1;
    delete ui->pushButton_1;
    delete ui->label_2;
    delete ui->pushButton_2;
    delete ui->label_3;
    delete ui->pushButton_3;
    delete ui->label_4;
    delete ui->pushButton_4;
    delete ui->label_5;
    delete ui->pushButton_5;
    delete ui->label_6;
    delete ui->pushButton_6;
    delete ui->label_7;
    delete ui->pushButton_7;
    delete ui->label_8;
    delete ui->pushButton_8;
    delete ui->label_9;
    delete ui->pushButton_9;
    delete ui->label_10;
    delete ui->pushButton_10;
    delete ui->label_11;
    delete ui->pushButton_11;
    delete ui->label_12;
    delete ui->pushButton_12;
    delete ui->label_13;
    delete ui->pushButton_13;
    delete ui->label_14;
    delete ui->pushButton_14;
    delete ui->label_15;
    delete ui->pushButton_15;
    delete ui->label_16;
    delete ui->pushButton_16;
    delete ui->label_17;
    delete ui->pushButton_17;
    delete ui->label_18;
    delete ui->pushButton_18;
    delete ui->label_19;
    delete ui->pushButton_19;
    delete ui->label_20;
    delete ui->pushButton_20;
    delete ui->actionAbout;
    delete ui->actionExit;
    delete ui->actionHow_to_Play;
    delete ui->actionImport_your_own_images;
    delete ui->actionPlay_again;
    delete ui->lcdNumber;
    delete ui->lcdNumber_2;
    delete ui->lcdNumber_3;


int numOfFiles =files.length()-1;
 bool hasUsed=false;
 srand(static_cast<unsigned int>(time(0)));//I found this to be able to use the current time to make sure that the randomization is different each time
    //QTimer * theTimer=new QTimer(this);
for(int i=0;i<10;++i){//time to get our 10 random images
   hasUsed=false;

    int rando = rand()%numOfFiles;
    QString imagePath;
    if(customImages==false){
       imagePath=("images/");
    }
   imagePath= directory.absoluteFilePath(imagePath);
   imagePath.append("/");
         imagePath.append(files.takeAt(rando));
         if(i>0){
    for(int g=0;g<i;g++){//check if the image was used before
        if(imagePath==theFiles[g])
            hasUsed=true;
    }
         }
    if(hasUsed==false)
  theFiles[i]=imagePath;

    else if(hasUsed==true){
        i--;//if it would have been a duplicate, rechoose it.
    }
//  theFiles[i]=theFiles[i].scaled(81,81);
    files.removeAt(rando);
    numOfFiles=numOfFiles-2;
}
for(int i=0;i<20;i++){
    boardImg[i]=0;//make sure everything is set for the for loops.
}
for(int a=0;a<2;a++){
     for(int b=0;b<10;b++){
        int rando =rand()%19;
        if(boardImg[rando]==0)
            boardImg[rando]=b;
        else
            b=b--;//try that number again
}
}

turns[0]=NULL;
turns[1]=NULL;
//int index=boardImg[1];
//QPixmap thePic(this->theFiles[index]);
//ui->label_2->setPixmap(thePic);
//ui->label->hide();
//thePic(theFiles[boardImg[0]]);
//ui->label->setPixmap( thePic);
//ui->actionPlay_again->setDisabled(true);
  //  QBasicTimer * theTimer=new QBasicTimer;
    ui->setupUi(this);

}
else{
        QMessageBox error;
        error.setText("Error: Not enough images available. Reverting to default.\n"
                      "Press OK to continue.");
        error.exec();
       }
}

void MainWindow::on_actionPlay_again_triggered()
{

customImages=false;//playagain will revert changes to images.
    delete ui->label_1;
    delete ui->pushButton_1;
    delete ui->label_2;
    delete ui->pushButton_2;
    delete ui->label_3;
    delete ui->pushButton_3;
    delete ui->label_4;
    delete ui->pushButton_4;
    delete ui->label_5;
    delete ui->pushButton_5;
    delete ui->label_6;
    delete ui->pushButton_6;
    delete ui->label_7;
    delete ui->pushButton_7;
    delete ui->label_8;
    delete ui->pushButton_8;
    delete ui->label_9;
    delete ui->pushButton_9;
    delete ui->label_10;
    delete ui->pushButton_10;
    delete ui->label_11;
    delete ui->pushButton_11;
    delete ui->label_12;
    delete ui->pushButton_12;
    delete ui->label_13;
    delete ui->pushButton_13;
    delete ui->label_14;
    delete ui->pushButton_14;
    delete ui->label_15;
    delete ui->pushButton_15;
    delete ui->label_16;
    delete ui->pushButton_16;
    delete ui->label_17;
    delete ui->pushButton_17;
    delete ui->label_18;
    delete ui->pushButton_18;
    delete ui->label_19;
    delete ui->pushButton_19;
    delete ui->label_20;
    delete ui->pushButton_20;
    delete ui->actionAbout;
    delete ui->actionExit;
    delete ui->actionHow_to_Play;
    delete ui->actionImport_your_own_images;
    delete ui->actionPlay_again;
    delete ui->lcdNumber;
    delete ui->lcdNumber_2;
    delete ui->lcdNumber_3;

//    ui->lcdNumber->display(gamesPlayed);


    tries=0;
    //gamesPlayed=0;
   solvedSquares=0;
 QDir directory;
           if(customImages==false){
    directory=QDir ("images/");
           }
    QStringList filters;
    filters<<"*.png"<<"*.jpeg"<<"*.bmp"<<"*.gif"<<"*.jpg"<<"*.pbm"<<"*.pgm"<<"*.ppm"<<"*.tiff"<<"*.xbm"<<"*.xpm";
    directory.setNameFilters(filters);
    QStringList files = directory.entryList();
int numOfFiles =files.length()-1;
 bool hasUsed=false;
 srand(static_cast<unsigned int>(time(0)));//I found this to be able to use the current time to make sure that the randomization is different each time
    //QTimer * theTimer=new QTimer(this);
for(int i=0;i<10;++i){//time to get our 10 random images
   hasUsed=false;

    int rando = rand()%numOfFiles;
    QString imagePath;
    if(customImages==false){
       imagePath=("images/");
    }
    else if(customImages==true){
        imagePath= directory.absoluteFilePath(imagePath);
        imagePath.append("/");
    }

         imagePath.append(files.takeAt(rando));
         if(i>0){
    for(int g=0;g<i;g++){//check if the image was used before
        if(imagePath==theFiles[g])
            hasUsed=true;
    }
         }
    if(hasUsed==false)
  theFiles[i]=imagePath;

    else if(hasUsed==true){
        i--;//if it would have been a duplicate, rechoose it.
    }
//  theFiles[i]=theFiles[i].scaled(81,81);
    files.removeAt(rando);
    numOfFiles=numOfFiles-2;
}
for(int i=0;i<20;i++){
    boardImg[i]=0;//make sure everything is set for the for loops.
}
for(int a=0;a<2;a++){
     for(int b=0;b<10;b++){
        int rando =rand()%19;
        if(boardImg[rando]==0)
            boardImg[rando]=b;
        else
            b=b--;//try that number again
}
}

turns[0]=NULL;
turns[1]=NULL;
//int index=boardImg[1];
//QPixmap thePic(this->theFiles[index]);
//ui->label_2->setPixmap(thePic);
//ui->label->hide();
//thePic(theFiles[boardImg[0]]);
//ui->label->setPixmap( thePic);
//ui->actionPlay_again->setDisabled(true);
  //  QBasicTimer * theTimer=new QBasicTimer;
    ui->setupUi(this);



}
void MainWindow::check(){
    theTimer->stop();
    if(turnsIndex[0]==turnsIndex[1]){//match
        turns[0]->hide();
        turns[1]->hide();
        turns[0]=NULL;
        solvedSquares=solvedSquares+2;
        turns[1]=NULL;
    }
    else{//no match. reset.

        turns[0]->hide();
        turns[1]->hide();
        turn[0]->show();
        turn[1]->show();
        turns[0]=NULL;
        turns[1]=NULL;
    }
    if(solvedSquares==20)
        gamesPlayed=gamesPlayed++;
}
