#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <queue>
#include <iostream>
#include <QPushButton>
#include <QTimer>
namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:

    QLabel * turns[2];//contains what slot was moved. first int is table location, second is piece index. if 0,0 and 1,1 are identical, match is found.
    QPushButton * turn[2];//turns and turn are both only used in checks to keep track of label and buttons for that turn
    int turnsIndex[2];

    QTimer * theTimer;
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_pushButton_1_clicked(bool checked);

    void on_pushButton_2_clicked(bool checked);

   void on_pushButton_4_clicked(bool checked);

   void on_pushButton_3_clicked(bool checked);

   void on_pushButton_8_clicked(bool checked);

   void on_pushButton_6_clicked(bool checked);

   void on_pushButton_7_clicked(bool checked);

   void on_pushButton_5_clicked(bool checked);

   void on_pushButton_12_clicked(bool checked);

   void on_pushButton_11_clicked(bool checked);

   void on_pushButton_10_clicked(bool checked);

   void on_pushButton_15_clicked(bool checked);

   void on_pushButton_14_clicked(bool checked);

   void on_pushButton_9_clicked(bool checked);

   void on_pushButton_13_clicked(bool checked);

   void on_pushButton_16_clicked(bool checked);

   void on_pushButton_20_clicked(bool checked);

   void on_pushButton_18_clicked(bool checked);

   void on_pushButton_17_clicked(bool checked);

   void on_pushButton_19_clicked(bool checked);
   void check();

   void on_actionExit_triggered();

   void on_actionAbout_triggered();

   void on_actionHow_to_Play_triggered();


   void on_actionImport_your_own_images_triggered();

   void on_actionPlay_again_triggered();

private:
    Ui::MainWindow *ui;
        int boardImg[20];
        QString theFiles[10];
    int solvedSquares;
    int tries;
bool customImages;

    int gamesPlayed;//only keeps track of complete games played.

};

#endif // MAINWINDOW_H
