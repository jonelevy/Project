/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created: Thu Apr 5 15:15:59 2012
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../project4/mainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWindow[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      26,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      20,   12,   11,   11, 0x08,
      50,   12,   11,   11, 0x08,
      80,   12,   11,   11, 0x08,
     110,   12,   11,   11, 0x08,
     140,   12,   11,   11, 0x08,
     170,   12,   11,   11, 0x08,
     200,   12,   11,   11, 0x08,
     230,   12,   11,   11, 0x08,
     260,   12,   11,   11, 0x08,
     291,   12,   11,   11, 0x08,
     322,   12,   11,   11, 0x08,
     353,   12,   11,   11, 0x08,
     384,   12,   11,   11, 0x08,
     415,   12,   11,   11, 0x08,
     445,   12,   11,   11, 0x08,
     476,   12,   11,   11, 0x08,
     507,   12,   11,   11, 0x08,
     538,   12,   11,   11, 0x08,
     569,   12,   11,   11, 0x08,
     600,   12,   11,   11, 0x08,
     631,   11,   11,   11, 0x08,
     639,   11,   11,   11, 0x08,
     665,   11,   11,   11, 0x08,
     692,   11,   11,   11, 0x08,
     725,   11,   11,   11, 0x08,
     769,   11,   11,   11, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0\0checked\0on_pushButton_1_clicked(bool)\0"
    "on_pushButton_2_clicked(bool)\0"
    "on_pushButton_4_clicked(bool)\0"
    "on_pushButton_3_clicked(bool)\0"
    "on_pushButton_8_clicked(bool)\0"
    "on_pushButton_6_clicked(bool)\0"
    "on_pushButton_7_clicked(bool)\0"
    "on_pushButton_5_clicked(bool)\0"
    "on_pushButton_12_clicked(bool)\0"
    "on_pushButton_11_clicked(bool)\0"
    "on_pushButton_10_clicked(bool)\0"
    "on_pushButton_15_clicked(bool)\0"
    "on_pushButton_14_clicked(bool)\0"
    "on_pushButton_9_clicked(bool)\0"
    "on_pushButton_13_clicked(bool)\0"
    "on_pushButton_16_clicked(bool)\0"
    "on_pushButton_20_clicked(bool)\0"
    "on_pushButton_18_clicked(bool)\0"
    "on_pushButton_17_clicked(bool)\0"
    "on_pushButton_19_clicked(bool)\0check()\0"
    "on_actionExit_triggered()\0"
    "on_actionAbout_triggered()\0"
    "on_actionHow_to_Play_triggered()\0"
    "on_actionImport_your_own_images_triggered()\0"
    "on_actionPlay_again_triggered()\0"
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: on_pushButton_1_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: on_pushButton_2_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: on_pushButton_4_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: on_pushButton_3_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: on_pushButton_8_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: on_pushButton_6_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: on_pushButton_7_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: on_pushButton_5_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: on_pushButton_12_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 9: on_pushButton_11_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: on_pushButton_10_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: on_pushButton_15_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 12: on_pushButton_14_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 13: on_pushButton_9_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 14: on_pushButton_13_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 15: on_pushButton_16_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 16: on_pushButton_20_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 17: on_pushButton_18_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 18: on_pushButton_17_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 19: on_pushButton_19_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 20: check(); break;
        case 21: on_actionExit_triggered(); break;
        case 22: on_actionAbout_triggered(); break;
        case 23: on_actionHow_to_Play_triggered(); break;
        case 24: on_actionImport_your_own_images_triggered(); break;
        case 25: on_actionPlay_again_triggered(); break;
        default: ;
        }
        _id -= 26;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
