#include <QtCore/QCoreApplication>
#include <iostream>
#include <stdlib.h>
#include <fstream>
using namespace std;


int main(int argc, char *argv[])
{
 bool verbose=false;bool html=false;bool output=false;char* outputFile;char* htmlFile;
        //char* fileName = ("proj1data1.txt");
    int board[9][9][10] ;//empty board. 9x9 squares, 9x9 3D array.
    //3d array means the third portion can be a list of possible numbers, and in the end the number that isn't a 0 is the final number.
    int a=0;int b=0;int c=0;//for loop counters
    int count;
    for(a=0;a<9;a++){
        for(b=0;b<9;b++){
            for(c=0;c<10;c++){
            board[a][b][c]=c;//sets all empty spots to empty.
        }
        }
                }

    for(a=0;a<argc;a++){//grabbing flags

        if(argc==2)
            break;
        if(strcmp(argv[a],"-v")==0){
            verbose=true;
        }
        if(strcmp(argv[a],"-o")==0){
            output=true;
           outputFile = argv[a+1];
        }
        if(strcmp(argv[a],"-h")==0){
            html=true;
            htmlFile = argv[a+1];
        }
    }

    ifstream sudokuStart (argv[argc-1]);



    string currentLine;
    //sudokuStart.clear();sudokuStart.seekg(0);
    //sudokuStart.open(fileName.c_str());//hardcoded test input
    //if(sudokuStart.is_open())
    while(getline(sudokuStart,currentLine)){
    //    cout<<currentLine;cout<<"\n";
    //getline(sudokuStart,currentLine);
      //cout<<currentLine + "\n";

        int x=currentLine[0]-'1';

   //x=x-49;
        int y=currentLine[2]-'1';

   // y=y-49;
    int num=currentLine[4]-'0';

    //num=num-48;
//cout<<getline(sudokuStart,currentLine);
    //cout<<x;
    //cout<<" ";
    //cout<<y;
  //  cout<<" ";
//cout<<num;
//cout<<"\n";
    board[x][y][0] = num;
    if(verbose==true){
        cout<<board[x][y][0];cout<<" placed at r/c ";cout<<(x+1);cout<<" ";cout<<(y+1);cout<<" due to being part of input.";cout<<"\n";
}
    }

    //-----------------------------------------------------------
    //---------------------candidate lists-----------------------
    //-----------------------------------------------------------
  //make sure those with preset numbers have no candidate lists
    for(a=0;a<9;a++){
        for(b=0;b<9;b++){
            if(board[a][b][0]!=0)
                for(c=1;c<10;c++){
                    board[a][b][c]=0;
             }
        }
    }

    //-----------------------9x9 squares------------------------

    for(c=0;c<=2;c++){
//having the three boxes check through a loop cuts down on lines. it makes it so with each coming row c increments, so for the second set of rows, it starts at index (2*2)-1 which is 3 where the second row starts indexwise

 //check first 3x3 block (indexes 0-2) for fixing candidate list
    int d;int e;//need more index variables for for loops
    for(a=0;a<=2;a++){
        for(b=0;b<=2;b++){
            if(board[a+(c*3)][b][0]!=0){
                int num = board[a+(c*3)][b][0];
               for(d=0;d<=2;d++){
                    for(e=0;e<=2;e++){

                        if((board[a+(c*3)][e][0]==0))
                            board[a+(c*3)][e][num]=0;//uses a method I created to grab the index of a candidate in an array, it sets what was initially grabbed, finds that same number in all other candidate lists in the first square and makes it a 0
                    }
                }
            }
        }
    }
    //check second 3x3 block (indexes 3-5 columns, (0-2 index for row) for fixing candidate list
        for(a=0;a<=2;a++){
            for(b=3;b<=5;b++){
                if(board[a+(c*3)][b][0]!=0){
                    int num = board[a+(c*3)][b][0];
                    for(d=0;d<=2;d++){
                        for(e=3;e<=5;e++){
                            if((board[d+(c*3)][e][0]==0))
                                board[d+(c*3)][e][num]=0;//uses a method I created to grab the index of a candidate in an array, it sets what was initially grabbed, finds that same number in all other candidate lists in the first square and makes it a 0
                        }
                    }
                }
            }
        }
        //check third 3x3 block (indexes 6-8 columns, (0-2 index for row) for fixing candidate list
            for(a=0;a<=2;a++){
                for(b=6;b<=8;b++){
                    if(board[a+(c*3)][b][0]!=0){
                        int num = board[a+(c*3)][b][0];
                        for(d=0;d<=2;d++){
                            for(e=6;e<=8;e++){
                                if((board[d+(c*3)][e][0]==0))
                                    board[d+(c*3)][e][num]=0;//uses a method I created to grab the index of a candidate in an array, it sets what was initially grabbed, finds that same number in all other candidate lists in the first square and makes it a 0
                            }
                        }
                    }
                }
            }

    }

   //-----------------by column----------------------
    //d in this case is the column or y coordinate number
int d;
    for(d=0;d<=8;d++){
    for(a=0;a<=8;a++){
        if(board[d][a][0]!=0){
            int num=board[d][a][0];
            for(b=0;b<=8;b++){
                if(board[b][a][0]==0)
                    board[b][a][num]=0;
            }
        }
    }
}
    //-----------------by row----------------------
    //d in this case is the row or x coordinate number
    for(d=0;d<=8;d++){
    for(a=0;a<=8;a++){
        if(board[d][a][0]!=0){
            int num=board[d][a][0];
            for(b=0;b<=8;b++){
                if(board[d][b][0]==0)
                    board[d][b][num]=0;
            }
        }
    }
}
    cout<<"---------------";cout<<"\n";
    for(a=0;a<9;a++){

        if(a==3||a==6){
      cout <<"||";cout<<"-----------";cout<<"|| \n";cout <<"||";
        }
        else
             cout <<"||";
        for(b=0;b<9;b++){

            if(board[a][b][0]==0)
                cout<<".";
            else
                cout<<board[a][b][0];
            if(b==2||b==5)
                cout<<"|";
        }
        cout <<"||";
        cout<<"\n";
    }
    cout<<"---------------";cout<<"\n";

    count=0;//this will be used to count the number of candidates left in any given location.
//-------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------
//----------------------------------------------singles--------------------------------------
//-------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------
bool madeChange =true;
while(madeChange==true){
madeChange=false;
//--------------------------------
//------------singles-------------
//-------------rows---------------
//--------------------------------


for(a=0;a<9;a++){
for(b=0;b<9;b++){
if(board[a][b][0]==0){
//check if only contains 1 value to use
    count=0;
for(c=1;c<10;c++){
    if(board[a][b][c]!=0){
        count++;
    }
}
if(count==1){
    madeChange=true;
    //go through count again, and grab the number
    for(c=1;c<10;c++){
        if(board[a][b][c]!=0){
            board[a][b][0]=c;
            if(verbose==true){
                cout<<board[a][b][0];cout<<" placed at r/c ";cout<<(a+1);cout<<" ";cout<<(b+1);cout<<" due to being a single.";cout<<"\n";
         }
                break;
        }
    }
    if(b>=6){
        if(a>=6)
            d=2;
        else if(a>=3)
            d=1;
        else if(a>=0)
            d=0;
        for(int e=0;e<3;e++){
            for( int f=6;f<9;f++){
                board[e+(d*3)][f][c]=0;
            }
        }
    }

    else if(b>=3){
        if(a>=6)
            d=2;
        else if(a>=3)
            d=1;
        else if(a>=0)
            d=0;
        for(int e=0;e<3;e++){
            for( int f=3;f<6;f++){
                board[e+(d*3)][f][c]=0;
            }
        }
    }

   else if(b>=0){
        if(a>=6)
            d=2;
        else if(a>=3)
            d=1;
        else if(a>=0)
            d=0;
        for(int e=0;e<3;e++){
            for( int f=0;f<3;f++){
                board[e+(d*3)][f][c]=0;
            }
        }
    }
            for(d=0;d<9;d++){
                board[d][b][c]=0;
                board[a][d][c]=0;
            }}}}}

//---------------------------------
//--------------singles------------
//-----------columns---------------
//---------------------------------

for(a=0;a<9;a++){
for(b=0;b<9;b++){
if(board[b][a][0]==0){
int count=0;
//check if only contains 1 value to use
for(c=1;c<10;c++){
    if(board[b][a][c]!=0){
        count++;
    }
}
if(count==1){
    madeChange=true;
    //go through count again, and grab the number
    for(c=1;c<10;c++){
        if(board[b][a][c]!=0){
            board[b][a][0]=c;
            if(verbose==true){
                cout<<board[b][a][0];cout<<" placed at r/c ";cout<<(b+1);cout<<" ";cout<<(a+1);cout<<" due to being a single.";cout<<"\n";
            }
         break;
        }
    }
    if(b>=6){
        if(a>=6)
            d=2;
        else if(a>=3)
            d=1;
        else if(a>=0)
            d=0;
        for(int e=0;e<3;e++){
            for( int f=6;f<9;f++){
                board[f][e+(d*3)][c]=0;
            }
        }
    }

    else if(b>=3){
        if(a>=6)
            d=2;
        else if(a>=3)
            d=1;
        else if(a>=0)
            d=0;
        for(int e=0;e<3;e++){
            for( int f=3;f<6;f++){
                board[f][e+(d*3)][c]=0;
            }
        }
    }

   else if(b>=0){
        if(a>=6)
            d=2;
        else if(a>=3)
            d=1;
        else if(a>=0)
            d=0;
        for(int e=0;e<3;e++){
            for( int f=0;f<3;f++){
                board[f][e+(d*3)][c]=0;
            }
        }
    }

            for(d=0;d<9;d++){
                board[b][d][c]=0;
                board[d][a][c]=0;
            }}}}}

//--------------------
//-------singles------
//-------blocks-------
//--------------------

for(int z=0;z<=2;z++){
for(a=0;a<3;a++){
for(b=0;b<3;b++){
    if(board[a+(z*3)][b][0]==0){
        count=0;
        for(c=1;c<10;c++){
            if(board[a+(z*3)][b][c]!=0)
                count++;
        }
        if(count==1){
            madeChange=true;
            for(c=1;c<10;c++){
                if(board[a+(z*3)][b][c]!=0){
                    board[a+(z*3)][b][0]=c;
                    if(verbose==true){
                        cout<<board[a+(z*3)][b][0];cout<<" placed at r/c ";cout<<(a+(z*3)+1);cout<<" ";cout<<(b+1);cout<<" due to being a single.";cout<<"\n";
                            }
                        break;
                    for(int d=0;d<3;d++){
                        for(int e=0;e<3;e++){
                            board[d+(z*3)][e][c]=0;//block clear if true
                        }
                    }
                    for(int d=0;d<9;d++){
                        board[a][d][c]=0;
                        board[d][b][c]=0;
                        board[d][a][c]=0;
                        board[b][d][c]=0;
                    }
                }
            }
        }
    }
}
}
for(a=0;a<3;a++){
for(b=3;b<6;b++){
    if(board[a+(z*3)][b][0]==0){
        count=0;
        for(c=1;c<10;c++){
            if(board[a+(z*3)][b][c]!=0)
                count++;
        }
        if(count==1){
            madeChange=true;
            for(c=1;c<10;c++){
                if(board[a+(z*3)][b][c]!=0){
                    board[a+(z*3)][b][0]=c;
                    if(verbose==true){
                        cout<<board[a+(z*3)][b][0];cout<<" placed at r/c ";cout<<(a+(z*3)+1);cout<<" ";cout<<(b+1);cout<<" due to being a single.";cout<<"\n";
                           }
                        break;
                    for(int d=0;d<3;d++){
                        for(int e=3;e<6;e++){
                            board[d+(z*3)][e][c]=0;//block clear if true
                        }
                    }
                    for(int d=0;d<9;d++){
                        board[a][d][c]=0;
                        board[d][b][c]=0;
                        board[d][a][c]=0;
                        board[b][d][c]=0;
                    }
                }
            }
        }
    }
}
}
for(a=0;a<3;a++){
for(b=6;b<9;b++){
    if(board[a+(z*3)][b][0]==0){
        count=0;
        for(c=1;c<10;c++){
            if(board[a+(z*3)][b][0]!=0)
                count++;
        }
        if(count==1){
            madeChange=true;
            for(c=1;c<10;c++){
                if(board[a+(z*3)][b][c]!=0){
                    board[a+(z*3)][b][0]=c;
                    if(verbose==true){
                        cout<<board[a+(z*3)][b][0];cout<<" placed at r/c ";cout<<(a+(z*3)+1);cout<<" ";cout<<(b+1);cout<<" due to being a single.";cout<<"\n";
                          }
                      break;
                    for(int d=0;d<3;d++){
                        for(int e=6;e<9;e++){
                            board[d+(z*3)][e][c]=0;//block clear if true
                        }
                    }
                    for(int d=0;d<9;d++){
                        board[a][d][c]=0;
                        board[d][b][c]=0;
                        board[d][a][c]=0;
                        board[b][d][c]=0;
                    }
                }
            }
        }
    }
}
}
}
//-------singles row check----------
for(a=0;a<9;a++){
for(b=0;b<9;b++){
if(board[a][b][0]!=0){
    int num=board[a][b][0];
    for(c=0;c<9;c++){
            board[a][c][num]=0;

    }
}
}
}

//-------singles column check----------
     for(a=0;a<9;a++){
         for(b=0;b<9;b++){
             if(board[b][a][0]!=0){
                 int num=board[b][a][0];
                 for(c=0;c<9;c++){
                         board[c][a][num]=0;

                 }
             }
         }
     }
     //singles block check
     for(a=0;a<=2;a++){
         for(b=0;b<3;b++){
             for(c=0;c<3;c++){
                 if(board[b+(a*3)][c][0]!=0){
                     int num=board[b+(a*3)][c][0];
                     for(d=0;d<3;d++){
                         for(int e=0;e<3;e++){
                             board[d+(a*3)][e][num]=0;
                         }
                     }
                 }
             }

         }
         for(b=0;b<3;b++){
             for(c=3;c<6;c++){
                 if(board[b+(a*3)][c][0]!=0){
                     int num=board[b+(a*3)][c][0];
                     for(d=0;d<3;d++){
                         for(int e=3;e<6;e++){
                             board[d+(a*3)][e][num]=0;
                         }
                     }
                 }
             }

         }
         for(b=0;b<3;b++){
             for(c=6;c<9;c++){
                 if(board[b+(a*3)][c][0]!=0){
                     int num=board[b+(a*3)][c][0];
                     for(d=0;d<3;d++){
                         for(int e=6;e<9;e++){
                             board[d+(a*3)][e][num]=0;
                         }
                     }
                 }
             }

         }
     }

}

//----------------------------------------------------------------------
//----------------------------------------------------------------------
//--------------------------naked pairs---------------------------------
//----------------------------------------------------------------------
//----------------------------------------------------------------------


    //-------------------------------
    //-----------naked pairs---------
    //-------------rows--------------
    //-------------------------------
    bool twoPairs=false;int paired[9];//for all 9 values in a given row, column, or block, if the index of the row is set to 1, don't look in it again for a pair. it had its chance.
    int pairA=0;int pairB=0;int rowA=0;int rowB=0;
    for(a=0;a<9;a++){
        for(c=0;c<9;c++){
            paired[c]=0;//reset the array
        }
       pairA=0;pairB=0;twoPairs=false;rowA=0;rowB=0;//new row, new pairs
        for(b=0;b<9;b++){
            if(twoPairs==true){//once two lists in the same row have the exact same pair of candidates, remove it from everywhere else
                for(d=0;d<9;d++){
                    if(d!=rowA||d!=rowB){
                        //if it isn't the same spot in the row of the pair,
                        board[a][d][pairA]=0;
                        board[a][d][pairB]=0;
                    }
                }
                paired[rowA]=1;
                paired[rowB]=1;
                pairA=0;pairB=0;twoPairs=false;rowA=0;rowB=0;//reset all the values so another pair may be found.
                b=0;//find a new pair
            }
            count=0;
            if(board[a][b][0]==0)
            for(c=1;c<10;c++){
                if(board[a][b][c]!=0)
                    count++;
                if(count==2){
                    for(c=1;c<10;c++){
                        if((board[a][rowA][pairA]==board[a][b][pairA])&&(board[a][rowA][pairB]==board[a][b][pairB])&&twoPairs==false&&pairA!=0&&pairB!=0&&paired[b]==0&&b!=rowA){
                            //then this might just be a match.
                           rowB=b;
                        }
                        if(board[a][b][c]!=0&&twoPairs==false&&pairA==0&&paired[b]==0){
                            pairA=c;
                            rowA=b;//the row of the first pair
                            c=c+1;//make sure that pairA and pairB will not be equal. period.
                        }
                        if(board[a][b][c]!=0&&twoPairs==false&&pairB==0&&paired[b]==0){
                            pairB=c;
                        }
        }
    }
}
}
}

    //-------------------------------
    //-----------naked pairs---------
    //-------------columns-----------
    //-------------------------------
    twoPairs=false;//for all 9 values in a given row, column, or block, if the index of the row is set to 1, don't look in it again for a pair. it had its chance.
     pairA=0; pairB=0; rowA=0; rowB=0;
    for(a=0;a<9;a++){
        for(c=0;c<9;c++){
            paired[c]=0;//reset the array
        }
       pairA=0;pairB=0;twoPairs=false;rowA=0;rowB=0;//new row, new pairs
        for(b=0;b<9;b++){
            if(twoPairs==true){//once two lists in the same row have the exact same pair of candidates, remove it from everywhere else
                for(d=0;d<9;d++){
                    if(d!=rowA||d!=rowB){
                        //if it isn't the same spot in the row of the pair,
                        board[d][a][pairA]=0;
                        board[d][a][pairB]=0;
                    }
                }
                paired[rowA]=1;
                paired[rowB]=1;
                pairA=0;pairB=0;twoPairs=false;rowA=0;rowB=0;//reset all the values so another pair may be found.
                b=0;//find a new pair
            }
            count=0;
            if(board[b][a][0]==0)
            for(c=1;c<10;c++){
                if(board[b][a][c]!=0)
                    count++;
                if(count==2){
                    for(c=1;c<10;c++){
                        if((board[rowA][a][pairA]==board[b][a][pairA])&&(board[rowA][a][pairB]==board[b][a][pairB])&&twoPairs==false&&pairA!=0&&pairB!=0&&paired[b]==0&&b!=rowA){
                            //then this might just be a match.
                           rowB=b;
                        }
                        if(board[b][a][c]!=0&&twoPairs==false&&pairA==0&&paired[b]==0){
                            pairA=c;
                            rowA=b;//the row of the first pair
                            c=c+1;//make sure that pairA and pairB will not be equal. period.
                        }
                        if(board[b][a][c]!=0&&twoPairs==false&&pairB==0&&paired[b]==0){
                            pairB=c;
                        }
        }
    }
}
}
}

    //-------------------------------
    //-----------naked pairs---------
    //-------------squares-----------
    //-------------------------------
    twoPairs=false;//for all 9 values in a given row, column, or block, if the index of the row is set to 1, don't look in it again for a pair. it had its chance.
     pairA=0; pairB=0; rowA=0; rowB=0;int columnA=0;int columnB=0;
     for(a=0;a<=2;a++){
         for(c=0;c<9;c++){
             paired[c]=0;//reset the array
         }
         for(b=0;b<3;b++){
             for(int f=0;f<3;f++){


                 count=0;

                 if(board[b+(a*3)][f][0]==0)
                 for(c=1;c<10;c++){

                     if(board[b+(a*3)][f][c]!=0){
                         count++;

                     }
                     if(count==2&&c==9){
                         for(c=1;c<10;c++){
                             if(twoPairs==true){//once two lists in the same row have the exact same pair of candidates, remove it from everywhere else
                                 for(d=0;d<3;d++){
                                     for(int e=0;e<3;e++){
                                     if((e!=columnA&&d!=rowA)||(e!=columnB&&d!=rowA)){
                                         //if it isn't the same spot in the row of the pair,
                                         board[d+(a*3)][e][pairA]=0;
                                         board[d+(a*3)][e][pairB]=0;
                                     }
                                     }
                                 }
                                 paired[rowA+(columnA*a)]=1;
                                 paired[rowB+(columnB*a)]=1;

                                 pairA=0;pairB=0;twoPairs=false;rowA=0;rowB=0;columnA=0;columnB=0;//reset all the values so another pair may be found.
                                 b=0;//find a new pair
                         }
                             if((board[columnA+(a*3)][rowA][pairA]==board[b+(a*3)][f][pairA])&&(board[columnA+(a*3)][rowA][pairB]==board[b+(a*3)][f][pairB])&&twoPairs==false&&pairA!=0&&pairB!=0&&paired[b+(a*3)]==0&&(b+(a*3))!=rowA&&f!=columnA){
                                 //then this might just be a match.
                                rowB=b;
                                columnB=f;
                                twoPairs=true;

                             }
                             if(board[b+(a*3)][f][c]!=0&&twoPairs==false&&pairA==0&&paired[f]==0){
                                 pairA=c;
                                 rowA=b;//the row of the first pair
                                 columnA=f;
                                 c=c+1;//make sure that pairA and pairB will not be equal. period.
                             }
                             if(board[b+(a*3)][f][c]!=0&&twoPairs==false&&pairB==0&&paired[f]==0){
                                 pairB=c;
                                 break;
                             }
             }
         }
         }
         for(c=0;c<9;c++){
             paired[c]=0;//reset the array
         }
    }
}
         for(c=0;c<9;c++){
             paired[c]=0;//reset the array
         }
            pairA=0;pairB=0;
         for(b=0;b<3;b++){
             for(int f=3;f<6;f++){


                 count=0;

                 if(board[b+(a*3)][f][0]==0)
                 for(c=1;c<10;c++){

                     if(board[b+(a*3)][f][c]!=0){
                         count++;

                     }
                     if(count==2&&c==9){
                         for(c=1;c<10;c++){
                             if(twoPairs==true){//once two lists in the same row have the exact same pair of candidates, remove it from everywhere else
                                 for(d=0;d<3;d++){
                                     for(int e=3;e<6;e++){
                                     if((e!=columnA&&d!=rowA)||(e!=columnB&&d!=rowA)){
                                         //if it isn't the same spot in the row of the pair,
                                         board[d+(a*3)][e][pairA]=0;
                                         board[d+(a*3)][e][pairB]=0;
                                     }
                                     }
                                 }
                                 paired[rowA+(columnA*a)]=1;
                                 paired[rowB+(columnB*a)]=1;

                                 pairA=0;pairB=0;twoPairs=false;rowA=0;rowB=0;columnA=0;columnB=0;//reset all the values so another pair may be found.
                                 b=0;//find a new pair
                         }
                             if((board[columnA+(a*3)][rowA][pairA]==board[b+(a*3)][f][pairA])&&(board[columnA+(a*3)][rowA][pairB]==board[b+(a*3)][f][pairB])&&twoPairs==false&&pairA!=0&&pairB!=0&&paired[b+(a*3)]==0&&(b+(a*3))!=rowA&&f!=columnA){
                                 //then this might just be a match.
                                rowB=b;
                                columnB=f;
                                twoPairs=true;

                             }
                             if(board[b+(a*3)][f][c]!=0&&twoPairs==false&&pairA==0&&paired[f]==0){
                                 pairA=c;
                                 rowA=b;//the row of the first pair
                                 columnA=f;
                                 c=c+1;//make sure that pairA and pairB will not be equal. period.
                             }
                             if(board[b+(a*3)][f][c]!=0&&twoPairs==false&&pairB==0&&paired[f]==0){
                                 pairB=c;
                                 break;
                             }
             }

         }
         }
         for(c=0;c<9;c++){
             paired[c]=0;//reset the array
         }
    }
}
         for(c=0;c<9;c++){
             paired[c]=0;//reset the array
         }
         for(b=0;b<3;b++){
             for(int f=6;f<9;f++){
                 if(twoPairs==true){//once two lists in the same row have the exact same pair of candidates, remove it from everywhere else
                     for(d=0;d<3;d++){
                         for(int e=6;e<9;e++){
                         if((d!=columnA&&e!=rowA)||(d!=columnB&&e!=rowA)){
                             //if it isn't the same spot in the row of the pair,
                             board[d+(a*3)][e][pairA]=0;
                             board[d+(a*3)][e][pairB]=0;
                         }
                         }
                     }
                     paired[rowA+(columnA*a)]=1;
                     paired[rowB+(columnB*a)]=1;

                     pairA=0;pairB=0;twoPairs=false;rowA=0;rowB=0;columnA=0;columnB=0;//reset all the values so another pair may be found.
                     b=0;//find a new pair
             }

                 count=0;

                 if(board[b+(a*3)][f][0]==0)
                 for(c=1;c<10;c++){

                     if(board[b+(a*3)][f][c]!=0){
                         count++;

                     }
                     if(count==2&&c==9){
                         for(c=1;c<10;c++){
                             if(twoPairs==true){//once two lists in the same row have the exact same pair of candidates, remove it from everywhere else
                                 for(d=0;d<3;d++){
                                     for(int e=6;e<9;e++){
                                     if((e!=columnA&&d!=rowA)||(e!=columnB&&d!=rowA)){
                                         //if it isn't the same spot in the row of the pair,
                                         board[d+(a*3)][e][pairA]=0;
                                         board[d+(a*3)][e][pairB]=0;
                                     }
                                     }
                                 }
                                 paired[rowA+(columnA*a)]=1;
                                 paired[rowB+(columnB*a)]=1;

                                 pairA=0;pairB=0;twoPairs=false;rowA=0;rowB=0;columnA=0;columnB=0;//reset all the values so another pair may be found.
                                 b=0;//find a new pair
                         }
                             if((board[columnA+(a*3)][rowA][pairA]==board[b+(a*3)][f][pairA])&&(board[columnA+(a*3)][rowA][pairB]==board[b+(a*3)][f][pairB])&&twoPairs==false&&pairA!=0&&pairB!=0&&paired[b+(a*3)]==0&&(b+(a*3))!=rowA&&f!=columnA){
                                 //then this might just be a match.
                                rowB=b;
                                columnB=f;
                                twoPairs=true;

                             }
                             if(board[b+(a*3)][f][c]!=0&&twoPairs==false&&pairA==0&&paired[f]==0){
                                 pairA=c;
                                 rowA=b;//the row of the first pair
                                 columnA=f;
                                 c=c+1;//make sure that pairA and pairB will not be equal. period.
                             }
                             if(board[b+(a*3)][f][c]!=0&&twoPairs==false&&pairB==0&&paired[f]==0){
                                 pairB=c;
                                 break;
                             }
                         }
         }
         }
         for(c=0;c<9;c++){
             paired[c]=0;//reset the array
         }
    }
}
     }

bool newCand=false; //if that number in a single candidite list is indeed the only one in the row, then go ahead and start the process of putting it in the 0 spot.

madeChange=true;
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//--------------------------------hidden singles--------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
while(madeChange==true){
madeChange=false;
           //--------------------------
          //--------hidden singles----
          //-----------rows-----------
          //--------------------------
          for(a=0;a<9;a++){
              for(b=0;b<9;b++){
                  newCand=false;
                  if(board[a][b][0]==0){
                      //possibility that it became a single, but there are other lists with that number. do a quick check.
                      count=0;
                      for(int h=1;h<10;h++){
                          if(board[a][b][h]!=0)
                              count++;
                      }
                      if(count==1){
                          newCand=true;

                          break;//if it is a single, force newCand true
                      }
                  for(c=1;c<10;c++){
                      if(board[a][b][c]!=0){
                      for(d=0;d<9;d++){//go through and check every possible that the candidate b has, and compare it to the rest of the row
                          if(board[a][b][c]==board[a][d][c]&&b!=d){
                             newCand=false;
                              break;//if the value is in 2 spots, go on to the next one.
                          }
                              else
                              newCand=true;
                      }
                      if(newCand==true){
                          madeChange=true;
                          board[a][b][0]=c;
                          if(verbose==true){
                              cout<<board[a][b][0];cout<<" placed at r/c ";cout<<(a+1);cout<<" ";cout<<(b+1);cout<<" due to being a hidden single.";cout<<"\n";
                                  }
                          for(int e=1;e<10;e++){
                              board[a][b][e]=0;
                          }
                          for(int e=0;e<9;e++){
                              board[a][e][c]=0;
                          }
                          for(int e=0;e<9;e++){
                              board[e][b][c]=0;
                          }
                      }
                  }
              }
          }
        }
          }
              //quick square check
              for(c=0;c<=2;c++){
                  for(a=0;a<3;a++){
                      for(b=0;b<3;b++){
                          if(board[a+(c*3)][b][0]!=0){
                              int num=board[a+(c*3)][b][0];
                              for(d=0;d<3;d++){
                                  for(int e=0;e<3;e++){
                                      board[d+(c*3)][e][num]=0;
                                  }}}}}
                  for(a=0;a<3;a++){
                      for(b=3;b<6;b++){
                          if(board[a+(c*3)][b][0]!=0){
                              int num=board[a+(c*3)][b][0];
                              for(d=0;d<3;d++){
                                  for(int e=3;e<6;e++){
                                      board[d+(c*3)][e][num]=0;
                                  }}}}}
                  for(a=0;a<3;a++){
                      for(b=6;b<9;b++){
                          if(board[a+(c*3)][b][0]!=0){
                              int num=board[a+(c*3)][b][0];
                              for(d=0;d<3;d++){
                                  for(int e=6;e<9;e++){
                                      board[d+(c*3)][e][num]=0;
                                  }}}}}}

          //--------------------------
          //--------hidden singles----
          //----------columns---------
          //--------------------------

          for(a=0;a<9;a++){
              for(b=0;b<9;b++){
                  newCand=false;
                  if(board[b][a][0]==0){
                      //possibility that it became a single, but there are other lists with that number. do a quick check.
                        count=0;
                      for(int h=1;h<10;h++){
                          if(board[b][a][h]!=0)
                              count++;
                      }
                      if(count==1){
                          newCand=true;

                          break;//if it is a single, force newCand true
                      }
                  for(c=1;c<10;c++){
                      if(board[b][a][c]!=0){
                      for(d=0;d<9;d++){//go through and check every possible that the candidate b has, and compare it to the rest of the row

                          if(board[b][a][c]==board[d][a][c]&&b!=d){
                             newCand=false;
                              break;//if the value is in 2 spots, go on to the next one.
                          }
                              else
                              newCand=true;
                      }
                      if(newCand==true){
                          madeChange=true;
                          board[b][a][0]=c;
                          if(verbose==true){
                              cout<<board[b][a][0];cout<<" placed at r/c ";cout<<(b+1);cout<<" ";cout<<(a+1);cout<<" due to being a hidden single.";cout<<"\n";
                                  }
                          for(int e=1;e<10;e++){
                              board[b][a][e]=0;
                          }
                          for(int e=0;e<9;e++){
                              board[e][a][c]=0;
                          }
                          for(int e=0;e<9;e++){
                              board[b][e][c]=0;
                          }
                      }
                  }
              }
          }
        }
        }


          //quick square check
          for(c=0;c<=2;c++){
              for(a=0;a<3;a++){
                  for(b=0;b<3;b++){
                      if(board[a+(c*3)][b][0]!=0){
                          int num=board[a+(c*3)][b][0];
                          for(d=0;d<3;d++){
                              for(int e=0;e<3;e++){
                                  board[d+(c*3)][e][num]=0;
                              }}}}}
              for(a=0;a<3;a++){
                  for(b=3;b<6;b++){
                      if(board[a+(c*3)][b][0]!=0){
                          int num=board[a+(c*3)][b][0];
                          for(d=0;d<3;d++){
                              for(int e=3;e<6;e++){
                                  board[d+(c*3)][e][num]=0;
                              }}}}}
              for(a=0;a<3;a++){
                  for(b=6;b<9;b++){
                      if(board[a+(c*3)][b][0]!=0){
                          int num=board[a+(c*3)][b][0];
                          for(d=0;d<3;d++){
                              for(int e=6;e<9;e++){
                                  board[d+(c*3)][e][num]=0;
                              }}}}}}


          //--------------------------
          //---hidden singles---------
          //-------by square----------
          //--------------------------

          for(int g=0;g<=2;g++){
              for(a=0;a<3;a++){
                  for(b=0;b<3;b++){
                      if(board[a+(g*3)][b][0]==0){
                          //check if its a single first
                          count=0;
                          for(int f=0;f<10;f++){
                              if(board[a+(g*3)][b][f]!=0)
                                  count++;
                          }
                          if(count==1){
                              madeChange=true;
                              for(int f=0;f<10;f++){
                                  if(board[a+(g*3)][b][f]!=0){
                                      board[a+(g*3)][b][0]=f;
                                      if(verbose==true){
                                          cout<<board[a+(g*3)][b][0];cout<<" placed at r/c ";cout<<(a+(g*3)+1);cout<<" ";cout<<(b+1);cout<<" due to being a hidden single.";cout<<"\n";
                                              }

                                      for(d=0;d<9;d++){
                                          board[a+(g*3)][d][f]=0;
                                          board[d][b][f]=0;
                                      }
                                      for(int h=1;h<10;h++){
                                          board[a+(g*3)][b][h]=0;
                                      }
                                      for(d=0;d<3;d++){
                                          for(int e=0;e<3;e++){
                                              board[d+(g*3)][e][f]=0;
                                          }
                                      }
                                  }
                              }
                            }
                        }
                    }
              }
              for(a=0;a<3;a++){
                  for(b=3;b<6;b++){
                      if(board[a+(g*3)][b][0]==0){
                          //check if its a single first
                          count=0;
                          for(int f=0;f<10;f++){
                              if(board[a+(g*3)][b][f]!=0)
                                  count++;
                          }
                          if(count==1){
                              madeChange=true;
                              for(int f=0;f<10;f++){
                                  if(board[a+(g*3)][b][f]!=0){
                                      board[a+(g*3)][b][0]=f;
                                      if(verbose==true){
                                          cout<<board[a+(g*3)][b][0];cout<<" placed at r/c ";cout<<(a+(g*3)+1);cout<<" ";cout<<(b+1);cout<<" due to being a hidden single.";cout<<"\n";
                                              }
                                      for(d=0;d<9;d++){
                                          board[a+(g*3)][d][f]=0;
                                          board[d][b][f]=0;
                                      }
                                      for(int h=1;h<10;h++){
                                          board[a+(g*3)][b][h]=0;
                                      }
                                      for(d=0;d<3;d++){
                                          for(int e=3;e<6;e++){
                                              board[d+(g*3)][e][f]=0;
                                          }
                                      }
                                  }
                              }
                            }
                        }
                    }
              }
              for(a=0;a<3;a++){
                  for(b=6;b<9;b++){
                      if(board[a+(g*3)][b][0]==0){
                          //check if its a single first
                          count=0;
                          for(int f=0;f<10;f++){
                              if(board[a+(g*3)][b][f]!=0)
                                  count++;
                          }
                          if(count==1){
                              madeChange=true;
                              for(int f=0;f<10;f++){
                                  if(board[a+(g*3)][b][f]!=0){
                                      board[a+(g*3)][b][0]=f;
                                      if(verbose==true){
                                          cout<<board[a+(g*3)][b][0];cout<<" placed at r/c ";cout<<(a+(g*3)+1);cout<<" ";cout<<(b+1);cout<<" due to being a hidden single.";cout<<"\n";
                                              }
                                      for(d=0;d<9;d++){
                                          board[a+(g*3)][d][f]=0;
                                          board[d][b][f]=0;
                                      }
                                      for(int h=1;h<10;h++){
                                          board[a+(g*3)][b][h]=0;
                                      }
                                      for(d=0;d<3;d++){
                                          for(int e=6;e<9;e++){
                                              board[d+(g*3)][e][f]=0;
                                          }
                                      }
                                  }
                              }
                            }
                        }
                    }
              }
}
}

//----------------------------------
//-----check for fully finished-----
//----------------------------------
bool isFinished = true;//true until proven false
//---------rows&columns-------------
for(a=0;a<9;a++){
    for(b=0;b<9;b++){
        if(board[b][a][0]==0)
            isFinished=false;
        if(board[a][b][0]==0)
            isFinished=false;
    }
}


if(isFinished==false)
    cout<<"Solution couldn't be finished. \n";
else
    cout<<"Solution fully completed. \n";

   cout<<"---------------";cout<<"\n";
   for(a=0;a<9;a++){

       if(a==3||a==6){
     cout <<"||";cout<<"-----------";cout<<"|| \n";cout <<"||";
       }
       else
            cout <<"||";
       for(b=0;b<9;b++){

           if(board[a][b][0]==0)
               cout<<".";
           else
               cout<<board[a][b][0];
           if(b==2||b==5)
               cout<<"|";
       }
       cout <<"||";
       cout<<"\n";
   }
   cout<<"---------------";cout<<"\n";

   if(output==true){//output to specified file
       ofstream outfile (outputFile,ofstream::binary);
       for(a=0;a<9;a++){
           for(b=0;b<9;b++){
               outfile<<(a+1);outfile<<" ";outfile<<(b+1);outfile<<" ";outfile<<board[a][b][0];outfile<<"\n";
           }
       }
   }
   if(html==true){//output to html file
       ofstream htmlfile (htmlFile,ofstream::binary);
       htmlfile<<"<head>";htmlfile<<"\n";
       htmlfile<<"<title>Sudoku Solver</title>";htmlfile<<"\n";
       htmlfile<<"</head";htmlfile<<"\n";
       htmlfile<<"<body>";htmlfile<<"\n";
       htmlfile<<"<table width=\"200\" border=\"1\">";htmlfile<<"\n";
       for(a=0;a<=2;a++){
                  htmlfile<<"<tr>";htmlfile<<"\n";
           htmlfile<<"<td><table width=\"200\" border=\"1\">";htmlfile<<"\n";
           for(b=0;b<3;b++){
               htmlfile<<"<tr>";htmlfile<<"\n";
               for(c=0;c<3;c++){
                   htmlfile<<"<td>";htmlfile<<board[b+(a*3)][c][0];htmlfile<<"</td>";htmlfile<<"\n";
               }
               htmlfile<<"</tr>";htmlfile<<"\n";
           }
           htmlfile<<"</table></td>";htmlfile<<"\n";
           htmlfile<<"<td><table width=\"200\" border=\"1\">";htmlfile<<"\n";
           for(b=0;b<3;b++){
               htmlfile<<"<tr>";htmlfile<<"\n";
               for(c=3;c<6;c++){
                   htmlfile<<"<td>";htmlfile<<board[b+(a*3)][c][0];htmlfile<<"</td>";htmlfile<<"\n";
               }
               htmlfile<<"</tr>";htmlfile<<"\n";
           }
           htmlfile<<"</table></td>";htmlfile<<"\n";
           htmlfile<<"<td><table width=\"200\" border=\"1\">";htmlfile<<"\n";
           for(b=0;b<3;b++){
               htmlfile<<"<tr>";htmlfile<<"\n";
               for(c=6;c<9;c++){
                   htmlfile<<"<td>";htmlfile<<board[b+(a*3)][c][0];htmlfile<<"</td>";htmlfile<<"\n";
               }
               htmlfile<<"</tr>";htmlfile<<"\n";
           }
           htmlfile<<"</table></td>";htmlfile<<"\n";
       }
       htmlfile<<"</tr>";htmlfile<<"\n";
       htmlfile<<"</table>";htmlfile<<"\n";
       htmlfile<<"</body>";htmlfile<<"\n";
       htmlfile<<"</html>";
   }



    //int d;
    //displays candidate lists
   /*
for(d=0;d<=6;d++){
        for(a=1;a<=3;a++){
        for(b=0;b<=2;b++){
            for(c=0;c<10;c++){
                //if(board[(a+d)-1][b][c]==0);
                //do nothing
                //else
                cout<<board[(a+d)-1][b][c];
            }
            cout<<"\n";
        }
    }
        cout<<"\n";cout<<"\n";
        for(a=1;a<=3;a++){
        for(b=3;b<=5;b++){
            for(c=0;c<10;c++){
                //if(board[(a+d)-1][b][c]==0);
                    //do nothing
                //else
                cout<<board[(a+d)-1][b][c];
            }
            cout<<"\n";
        }
    }
        cout<<"\n";cout<<"\n";
        for(a=1;a<=3;a++){
        for(b=6;b<=8;b++){
            for(c=0;c<10;c++){
               // if(board[(a+d)-1][b][c]==0);
                    //do nothing
               // else
                cout<<board[(a+d)-1][b][c];
            }
            cout<<"\n";
        }
    }
        cout<<"\n";cout<<"\n";
d=d+2;
}*/
        }
