#include "move.h"

Move::Move()
{
}
Move::Move(char p, char d, int pace){
    piece=p;
    direction=d;
    paces=pace;
}
