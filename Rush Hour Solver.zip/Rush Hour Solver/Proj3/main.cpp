#include <QtCore/QCoreApplication>
#include <iostream>
#include <fstream>
#include <piece.h>
#include <stdlib.h>
#include <snapshot.h>
#include <queue>
#include <move.h>
#include <set>
using namespace std;
Pieces dataGather (string line, char piece){//gathers the data from the line and passes it through pieceMaker which sends it to main.
    char data[5];
    int dataIndex=0;
    for(int a=0;a<line.length();a++){
        char temp=line[a];
        if(temp!=' '){
            data[dataIndex]=line[a];
            dataIndex++;
        }

    }
    int rowStart = data[0]-'0';
    int columnStart = data[1]-'0';
    int width = data[2]-'0';
    int height = data[3]-'0';
    char movType = data[4];
    return Pieces (rowStart,columnStart,width,height,movType,piece);
}
inline bool notInHistory(char *current,multiset<string> history) {
        bool notThere = false;
        if(history.count(current) == 0) notThere=true;
        return notThere;
}




void snapStack(deque<snapshot> theBoard,Pieces theList[],int rows, int columns,char pieces[]){

    snapshot goal =theBoard.front();//because it can't be declared in the loop of death
    multiset<string> history;//to make sure the history of boards doesn't repeat itself (heh)
    history.insert(goal.board);
    while(!theBoard.empty()){
        snapshot current = theBoard.front();
        theBoard.pop_front();

        if(current.isGoal(rows,columns,current.getBoard())){
                goal=current;
                break;
    }
        else{
            //get number of pieces
            int piecesNo=0;
                for(int a=0;a<128;a++){
                    if(theList[a].getPiece()!='.')
                        piecesNo++;
                }
            for(int a=0;a<piecesNo;a++){
                Pieces thePiece=theList[a];//start with THIS piece, cause its the piece.
                //horizontal movement foist
                if(thePiece.getType()=='b'||thePiece.getType()=='h'){
                    for(int b=1;b<columns;++b){
                        if(current.moveRight(thePiece.getPiece(),b,columns,rows)){
                            snapshot theNew(current.movingRight(thePiece.getPiece(),b));//creates a new snapshot for the newly moved piece.
                            if(notInHistory(theNew.getBoard(),history)){
                                theBoard.push_front(theNew);//if it all checks out and not a duplicate, push it onto the front of the stack.
                                history.insert(theNew.board);
                            }
                        }
                        else b=columns;
                    }
                    //left shifting!
                    for(int b=1;b<columns;++b){
                        if(current.moveLeft(thePiece.getPiece(),b,columns)){
                            snapshot theNew(current.movingLeft(thePiece.getPiece(),b));
                            if(notInHistory(theNew.getBoard(),history)){
                                theBoard.push_front(theNew);
                                history.insert(theNew.board);
                            }
                        }
                      else b=columns;
                                    }
                                }
                //vertical now
                if(thePiece.getType()=='b'||thePiece.getType()=='v'){
                    for(int b=1;b<rows;b++){
                        if(current.moveUp(thePiece.getPiece(),b,columns)){
                            snapshot theNew (current.movingUp(thePiece.getPiece(),b));
                            if(notInHistory(theNew.getBoard(),history)){
                                theBoard.push_front(theNew);
                                history.insert(theNew.board);
                            }
                        }
                        else b=rows;
                    }
                    //now for down
                    for(int b=1;b<rows;++b){
                        if(current.moveDown(thePiece.getPiece(),b,columns,rows)){
                            snapshot theNew (current.movingDown(thePiece.getPiece(),b));
                            if(notInHistory(theNew.getBoard(),history)){
                                theBoard.push_front(theNew);
                                history.insert(theNew.board);
                            }
                        }
                        else b=rows;
                    }
                }
            }

        }
    }

   // cout<<pieces;
    if(goal.isGoal(rows,columns,goal.getBoard())){

        while(!goal.moves.empty()) {
                cout << "Move piece " << goal.moves.front().getPiece();
                switch(goal.moves.front().getDir()) {
                        case 'l':
                                cout << " left by ";
                                break;
                        case 'u':
                                cout << " up by ";
                                break;
                        case 'd':
                                cout << " down by ";
                                break;
                        case 'r':
                                cout << " right by ";
                                break;
                }
                cout << goal.moves.front().getPaces() << " positions" << endl;
                goal.moves.pop_front();
        }
        cout << endl << "Solution:" << endl;
        goal.print(rows,columns);
        cout << "The puzzle has been solved";
    }
else
        cout<<"the board was not solved for whatever reason.";
    }

int main(int argc, char *argv[])
{
    if(argc>1){
        ifstream input(argv[1]);
            string currentLine;
        getline(input,currentLine);
        int rows=currentLine[0]-'0'+1;
        int columns = currentLine [currentLine.length()-1]-'0'+1;//accomidating for 2 spaces (will be fixed to all inbetween white space)
        if(rows>0&&columns>0){
        char  board[1000][1000];//creates the outer boarder of the board. 10000 is max size, rows and columns are current bounds
        char pieceAscii[128];
        pieceAscii[0]='Z';

        for(int a=1;a<26;a++){
            if(a==1)
                pieceAscii[a]='1';
            if(a==2)
                pieceAscii[a]='2';
            if(a==3)
                pieceAscii[a]='3';
            if(a==4)
                pieceAscii[a]='4';
            if(a==5)
                pieceAscii[a]='5';
            if(a==6)
                pieceAscii[a]='6';
            if(a==7)
                pieceAscii[a]='7';
            if(a==8)
                pieceAscii[a]='8';
            if(a==9)
                pieceAscii[a]='9';
            if(a==10)
                pieceAscii[a]='a';
            if(a==11)
                pieceAscii[a]='b';
            if(a==12)
                pieceAscii[a]='c';
            if(a==13)
                pieceAscii[a]='d';
            if(a==14)
                pieceAscii[a]='e';
            if(a==15)
                pieceAscii[a]='f';
            if(a==16)
                pieceAscii[a]='g';
            if(a==17)
                pieceAscii[a]='h';
            if(a==18)
                pieceAscii[a]='i';
            if(a==19)
                pieceAscii[a]='j';
            if(a==20)
                pieceAscii[a]='k';
            if(a==21)
                pieceAscii[a]='l';
            if(a==22)
                pieceAscii[a]='m';
            if(a==23)
                pieceAscii[a]='n';
            if(a==24)
                pieceAscii[a]='o';
            if(a==25)
                pieceAscii[a]='p';
            if(a==26)
                pieceAscii[a]='q';
        }
        for(int a=0;a<=rows;a++){//sets up the outer boarder
            for(int b=0;b<=columns;b++){
                if(a==0||a==rows||b==0||b==columns)
                    board[a][b]='*';
                else
                    board[a][b]='.';
            }
        }
        Pieces pieceList[128];
        for(int a=0;a<128;a++){
            pieceList[a]=Pieces();//the list of all pieces that are going to be used on the board. The max is 128 since there is a max of 128 pieces.
        }
    int pieceNo=0;

    while(getline(input,currentLine)){
        if(pieceNo==0)
            pieceList[0]=dataGather(currentLine,'Z');
        if(pieceNo>0)
        pieceList[pieceNo]=dataGather(currentLine,pieceAscii[pieceNo]);//since Z is host piece
       pieceNo++;
  }
    //now that we have the goal piece, start to go through the rest as long as input remains
    for(int a=0;a<128;a++){
        char checkPiece=pieceList[a].getPiece();
        if(checkPiece!='.'){
            int startR=pieceList[a].getRow();
            int startC=pieceList[a].getColumn();
            int height=startR+pieceList[a].getHeight();
            int width=startC+pieceList[a].getWid();
            for(int b=startR;b<height;b++){
                for(int c=startC;c<width;c++){
                    board[b][c]=checkPiece;
                }
            }
        }
    }
    int newRows=rows-1;
    int newColumns=columns-1;
    int newSize=newRows*newColumns;
    char pieces[newSize];//the reason why -1 is because row "row" and row 0 as well as column "column" and column 0 are asterisks
    int index=0;
    for(int a=1;a<=newRows;a++){
        for(int b=1;b<=newColumns;b++){
            pieces[index]=board[a][b];
            index++;
        }
    }
   /* for(int c=0;c<newSize;c++){
        if(pieces[c]!=' '){
        cout<<c;cout<<" ";cout<<pieces[c];cout<<"\n";
        }
    }*/
        deque<snapshot> boards;
        snapshot firstSnapshot=snapshot(newRows,newColumns,*pieces,*pieceList);
        boards.push_front(firstSnapshot);//push the original board onto the stack

        snapStack(boards,pieceList,newRows,newColumns,pieces);
    //board assemble
    //for(int a=0;a<=rows;a++){
      //  for(int b=0;b<=columns;b++){
        //        cout<<board[a][b];
       // }

        //cout<<"\n";
  //  }
    }
    }
    else
        cout<<"out of bounds error. Too small board.";
}

