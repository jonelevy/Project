#include "snapshot.h"
#include <iostream>
using namespace std;
snapshot::snapshot()
{
}
snapshot::snapshot( int r, int c,char& b,Pieces& p){//this just holds the basic info
columns = c;
rows = r;
size=rows*columns;
board=&b;
pieces=&p;
preceding=NULL;
move=NULL;
}
snapshot::snapshot(int r, int c, char &b, Pieces &p, snapshot* z){
    columns = c;
    rows = r;
    size=rows*columns;
    board=&b;
    pieces=&p;
    preceding=z;
    move=NULL;
}
void snapshot::print(int r,int c){
    int fullColumn=c+2;
    for(int a=0;a<fullColumn;a++){
        cout<<"*";
    }
    cout<<"\n";
    for(int a=0;a<r;a++){
        for(int b=0;b<fullColumn;b++){
            if(b==0||b==fullColumn-1)
                cout<<"*";
             else
                cout<<board[a+b];
        }
        cout<<"\n";
    }
    for(int a=0;a<fullColumn;a++){
        cout<<"*";
    }
}
bool snapshot::isGoal(int rows, int columns, char* board) {//checks for possible goal set
        bool metGoal=false;
        for(int i=0; i<rows*columns; ++i) {
                if(board[i] == 'Z') {
                        if(i%columns > 0 && (i+1)%columns == 0) metGoal=true;
                        else if(1%columns == 0 && (i+1)%columns == 0) metGoal=true;
                }
        }
        return metGoal;
}
bool snapshot::moveUp(char piece, int paces, int column){//column is number of columns to be able to check a 1d array as if it was a 2d array
    bool canMove=true;//if it can't find obstruction, move is all good.
    int rowNo=1;
    for(int i=0; i<size; ++i) {//the for loop means you don't care about the size of the piece as long as everything works
        //cout<<board[i];cout<<"\n";
        if(board[i] ==piece) {
            if(board[i-(paces*column)] != '.'||rowNo==1)
                          canMove=false;
                }

        if(i==((column*rowNo)))
            rowNo++;
    }
    return canMove;
}
bool snapshot::moveDown(char piece, int paces, int column, int rows){//column is number of columns to be able to check a 1d array as if it was a 2d array
    bool canMove=true;//if it can't find obstruction, move is all good.
   int rowNo=1;
    for(int i=0; i<size; ++i) {//the for loop means you don't care about the size of the piece as long as everything works
            if(board[i] == piece) {

             if(!((board[i+(paces*columns)] == '.' || board[i+(paces*columns)] == piece) && i+(paces*columns) < column*rows))
                            canMove=false;
            }
            if(i==((column*rowNo)))
                rowNo++;
    }
    return canMove;
}
bool snapshot::moveRight(char piece,int paces, int column,int rows){
    bool canMove=true;
    int rowNo=1;
    for(int i=0;i<size;i++){
        if(i==((column*rowNo)))//that means new row
            rowNo++;
        if(board[i]==piece){

            for(int a=1;a<=paces;a++){
                if(board[i+a]!='.'||i==rowNo*column)
                    canMove=false;
            }

        }

    }
return canMove;
}
bool snapshot::moveLeft(char piece,int paces, int column){
    bool canMove=true;
    int rowNo=1;
    for(int i=0;i<size;i++){
        if(i==((column*rowNo)))
            rowNo++;
        if(board[i]==piece){

            if((board[i-paces] == '.' || board[i-paces] == piece) && i-paces >= 0) {
                    for(int j=i; j>i-paces; --j)
                            if(j%columns == 0 && (j-1)%columns > 0) canMove=false;
            }
            else canMove=false;
            }






    }
return canMove;

}
snapshot snapshot::movingUp(char piece, int paces){
    snapshot snapshotTwo(*this);

        for(int i=0; i<size; ++i) {//the for loop means you don't care about the size of the piece as long as everything works
            //cout<<board[i];cout<<"\n";
            if(board[i] ==piece) {
                char temp = snapshotTwo.board[i-(paces*columns)];
                snapshotTwo.board[i-(paces*columns)]=snapshotTwo.board[i];
                snapshotTwo.board[i]=temp;


        }
}
        //add ths movement to queue
            Move theMove(piece,'U',paces);
            snapshotTwo.moves.push_front(theMove);
            return snapshotTwo;
}

snapshot snapshot::movingDown(char piece, int paces){
    snapshot snapshotTwo(*this);

        for(int i=0; i<size; ++i) {//the for loop means you don't care about the size of the piece as long as everything works
            //cout<<board[i];cout<<"\n";
            if(board[i] ==piece) {
                char temp = snapshotTwo.board[i+(paces*columns)];
                snapshotTwo.board[i+(paces*columns)]=snapshotTwo.board[i];
                snapshotTwo.board[i]=temp;


        }
}
        //add ths movement to queue
            Move theMove(piece,'D',paces);
            snapshotTwo.moves.push_front(theMove);
            return snapshotTwo;
}

snapshot snapshot::movingRight(char piece,int paces){
    snapshot snapshotTwo(*this);
    for(int i=size-1;i>=0;--i){
        if(snapshotTwo.board[i]==piece){
            snapshotTwo.board[i]=snapshotTwo.board[i+paces];
            snapshotTwo.board[i+paces]=piece;
        }
    }
    //add ths movement to queue
        Move theMove(piece,'R',paces);
        snapshotTwo.moves.push_front(theMove);
    return snapshotTwo;
}
snapshot snapshot::movingLeft(char piece,int paces){
    snapshot snapshotTwo(*this);
    for(int i=0;i<size;++i){
        if(snapshotTwo.board[i]==piece){
            char temp = snapshotTwo.board[i-paces];
            snapshotTwo.board[i-paces]=snapshotTwo.board[i];
            snapshotTwo.board[i]=temp;
        }
    }//add ths movement to queue
    Move theMove(piece,'L',paces);
    snapshotTwo.moves.push_front(theMove);
    return snapshotTwo;
}
