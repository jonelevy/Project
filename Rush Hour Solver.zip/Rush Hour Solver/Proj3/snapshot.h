#ifndef SNAPSHOT_H
#define SNAPSHOT_H
#include <move.h>
#include <queue>
#include <piece.h>
class snapshot
{
public:
    deque <Move> moves;//need a place to start the queue as to avoid continuous emptying

    snapshot();
    snapshot(int, int,char& ,Pieces&);
    snapshot(int,int,char&,Pieces&,snapshot*);
  //  snapshot basicBoard(char*,Pieces*,snapshot);
  //
    bool moveUp(char,int,int);
    bool moveDown (char,int,int,int);//you need to know number of rows for moveDown
    bool moveRight (char,int,int,int);
    bool moveLeft (char,int,int);

    char* board;//stores board
    Pieces* pieces;//stores the list of pieces for reference

    snapshot movingUp(char,int);
    snapshot movingDown(char,int);
    snapshot movingRight(char,int);
    snapshot movingLeft(char,int);

    char* getBoard () {return board;}
    int setMove (int lastMove) {move=lastMove;return move;}
    snapshot *preceding;
    int move;

    void print (int,int);
    bool isGoal(int, int, char*);


private:
    int rows;
    int columns;
    int size;

    };
#endif // SNAPSHOT_H
