#ifndef MOVE_H
#define MOVE_H
#include <iostream>

using namespace std;
class Move
{
public:
    Move();
    Move(char piece, char direction, int paces);
    char getDir () {return direction;}
    char getPiece () {return piece;}
    int getPaces () {return paces;}
    char direction;
    char piece;
    int paces;
private:

};

#endif // MOVE_H
