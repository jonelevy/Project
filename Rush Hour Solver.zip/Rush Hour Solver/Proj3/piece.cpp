#include "piece.h"

Pieces::Pieces()
{
    pieceChar='.';
    row = 0;
column = 0;
width = 0;
height = 0;
movType = 'b';
}
Pieces::Pieces(int r, int c, int w, int h, char m, char p){
    row = r;
    column=c;
    width=w;
    height=h;
    movType=m;
    pieceChar=p;
}
