#ifndef PIECE_H
#define PIECE_H

class Pieces
{
public:
    Pieces();
    Pieces(int,int,int,int,char,char);
    char getType() {return movType;}
    int getWid() {return width;}
    int getHeight() {return height;}
    int getRow() {return row;}
    int getColumn() {return column;}
    char getPiece() {return pieceChar;}
    int setRow(int newRow,char pieceChar) {row=newRow;return row;}
    int setColumn (int newColumn, char pieceChar) {column=newColumn;return column;}
    int getHeight(char pieceChar) {return height;}
    int getWid (char pieceChar) {return width;}
    char getType (char pieceChar) {return movType;}
    int getRow (char pieceChar) {return row;}
    int getColumn (char pieceChar) {return row;}

private:
int row;
int column;
int width;
int height;
char movType;
char pieceChar;

};
#endif // PIECE_H
